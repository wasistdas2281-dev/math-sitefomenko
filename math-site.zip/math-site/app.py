from flask import Flask, render_template, request
from sympy import sympify, symbols
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import os

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/theory")
def theory():
    return render_template("Theory.html")


@app.route("/examples")
def examples():
    return render_template("examples.html")


@app.route("/practice", methods=["GET", "POST"])
def practice():
    result = None
    expr = ""

    if request.method == "POST":
        expr = request.form.get("expr", "")
        try:
            symbolic = sympify(expr)
            numeric = symbolic.evalf()
            result = f"{symbolic} = {numeric}"
        except Exception:
            result = "Помилка у введенні математичного виразу. Перевірте синтаксис."

    return render_template("practice.html", result=result, expr=expr)


@app.route("/graph", methods=["GET", "POST"])
def graph():
    filename = None
    func_str = ""

    if request.method == "POST":
        func_str = request.form.get("func", "")
        try:
            x = symbols("x")
            f = sympify(func_str)

            xs = np.linspace(-10, 10, 400)
            ys = [f.subs(x, val) for val in xs]

            plt.figure(figsize=(6, 4))
            plt.plot(xs, ys)
            plt.grid(True)
            plt.xlabel("x")
            plt.ylabel("f(x)")
            plt.title("Графік функції")

            static_dir = os.path.join(BASE_DIR, "static")
            os.makedirs(static_dir, exist_ok=True)
            filename = "graph.png"
            filepath = os.path.join(static_dir, filename)

            plt.savefig(filepath, bbox_inches="tight")
            plt.close()
        except Exception:
            filename = None

    return render_template("graph.html", filename=filename, func=func_str)


if __name__ == "__main__":
    app.run(debug=True)
